document.documentElement.setAttribute('data-rr-public','1');try{const b=new URLSearchParams(location.search).get('rrb');if(b)sessionStorage.rrb=b}catch(e){}
const q=location.search;if(/[?&]rr=1/.test(q))sessionStorage.rr=1;if(/[?&]rrlike=1/.test(q))sessionStorage.rrlike=1;

/* 6.12.6: a radio tab never shows YouTube underneath while it loads; the radio lifts this cover once it is drawn */
try{if(sessionStorage.rr&&!document.getElementById('rrcov')){let bg='#0b0b0e';try{bg=localStorage.rrbg||bg}catch(e){}const c=document.createElement('div');c.id='rrcov';c.setAttribute('style','position:fixed;inset:0;z-index:2147483647;pointer-events:none;transition:opacity .3s;background:'+bg);document.documentElement.appendChild(c);setTimeout(()=>{try{c.remove()}catch(e){}},9000)}}catch(e){}
