if(typeof importScripts==='function')importScripts('cfg.js');
const dc=s=>[...atob(s)].map((c,i)=>String.fromCharCode(c.charCodeAt(0)^'rradiation'.charCodeAt(i%10))).join(''),KEY=dc(_C[0]);
function md5(s){s=unescape(encodeURIComponent(s));const K=[],S=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21];for(let i=0;i<64;i++)K[i]=Math.floor(Math.abs(Math.sin(i+1))*4294967296)>>>0;
 const n=s.length,w=[];for(let i=0;i<n;i++)w[i>>2]|=s.charCodeAt(i)<<(i%4*8);w[n>>2]|=128<<(n%4*8);const L=((n+8>>6)+1)*16;for(let i=0;i<L;i++)w[i]=w[i]|0;w[L-2]=n*8;
 let a=1732584193,b=-271733879,c=-1732584194,d=271733878;
 for(let o=0;o<L;o+=16){let A=a,B=b,C=c,D=d;for(let i=0;i<64;i++){let f,g;if(i<16){f=(B&C)|(~B&D);g=i}else if(i<32){f=(D&B)|(~D&C);g=(5*i+1)%16}else if(i<48){f=B^C^D;g=(3*i+5)%16}else{f=C^(B|~D);g=(7*i)%16}
  const t=D;D=C;C=B;const x=(A+f+K[i]+w[o+g])|0,r=S[(i>>4)*4+i%4];B=(B+((x<<r)|(x>>>(32-r))))|0;A=t}
  a=(a+A)|0;b=(b+B)|0;c=(c+C)|0;d=(d+D)|0}
 return[a,b,c,d].map(v=>{let h='';for(let i=0;i<4;i++)h+=('0'+((v>>>(i*8))&255).toString(16)).slice(-2);return h}).join('')}
const sign=(p,sec)=>md5(Object.keys(p).sort().map(k=>k+p[k]).join('')+sec);
async function post(p){const {sec,sk,ak}=await chrome.storage.local.get(['sec','sk','ak']);if(!sec||!sk)return;p={...p,api_key:ak||KEY,sk};p.api_sig=sign(p,sec);p.format='json';
 return fetch('https://ws.audioscrobbler.com/2.0/',{method:'POST',body:new URLSearchParams(p)}).then(r=>r.json()).catch(()=>{})}
async function auth(sec,ak){await chrome.storage.local.set({sec,ak});const K=ak||KEY;const g=p=>{p={...p,api_key:K};p.api_sig=sign(p,sec);p.format='json';return fetch('https://ws.audioscrobbler.com/2.0/?'+new URLSearchParams(p)).then(r=>r.json())};
 const t=(await g({method:'auth.getToken'})).token;if(!t)return;chrome.tabs.create({url:`https://www.last.fm/api/auth/?api_key=${K}&token=${t}`});
 for(let i=0;i<60;i++){await new Promise(r=>setTimeout(r,3000));const j=await g({method:'auth.getSession',token:t}).catch(()=>({}));if(j.session){await chrome.storage.local.set({sk:j.session.key,user:j.session.name});return}}}
const OK=/^https:\/\/(i\.ytimg\.com|en\.wikipedia\.org|itunes\.apple\.com|api\.discogs\.com|[\w-]+\.mzstatic\.com|i\.discogs\.com|st\.discogs\.com|musicbrainz\.org)\//;
const mark=(k,id)=>chrome.storage.session.get(k).then(o=>chrome.storage.session.set({[k]:[...(o[k]||[]).slice(-50),id]}));chrome.action.onClicked.addListener(()=>chrome.tabs.create({url:'https://www.youtube.com/?rr=1'}).then(t=>mark('rt',t.id)));
chrome.commands&&chrome.commands.onCommand.addListener(()=>chrome.tabs.query({url:'https://www.youtube.com/*'}).then(a=>a.forEach(t=>chrome.tabs.sendMessage(t.id,{next:1}).catch(()=>{}))));
const tokReq=q=>fetch('https://accounts.spotify.com/api/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(q)}).then(r=>r.json());
async function spAccess(){const {spt}=await chrome.storage.local.get('spt');if(!spt)return;if(Date.now()<spt.exp-30000)return spt.at;const r=await tokReq({grant_type:'refresh_token',refresh_token:spt.rt,client_id:spt.cid}).catch(()=>({}));if(!r.access_token)return;const n={...spt,at:r.access_token,rt:r.refresh_token||spt.rt,exp:Date.now()+r.expires_in*1e3};await chrome.storage.local.set({spt:n});return n.at}
const b64u=a=>btoa(String.fromCharCode(...new Uint8Array(a))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
async function spAuth(cid){if(!chrome.identity||!chrome.identity.launchWebAuthFlow)return{err:'Spotify login is not available in this browser. Use the data import in Settings.'};try{const ver=b64u(crypto.getRandomValues(new Uint8Array(48))),ch=b64u(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(ver))),ru=chrome.identity.getRedirectURL();
 const res=await chrome.identity.launchWebAuthFlow({interactive:true,url:'https://accounts.spotify.com/authorize?'+new URLSearchParams({client_id:cid,response_type:'code',redirect_uri:ru,code_challenge_method:'S256',code_challenge:ch,scope:'user-top-read user-library-read user-read-recently-played'})});
 const code=new URL(res).searchParams.get('code');if(!code)return{err:'No code returned'};
 const r=await tokReq({grant_type:'authorization_code',code,redirect_uri:ru,client_id:cid,code_verifier:ver});if(!r.access_token)return{err:r.error_description||r.error||'Token error'};
 await chrome.storage.local.set({spt:{at:r.access_token,rt:r.refresh_token,exp:Date.now()+r.expires_in*1e3,cid}});return{ok:1}}catch(e){return{err:String(e.message||e)}}}
chrome.runtime.onMessage.addListener((m,s,r)=>{
 if(m.spAuth){spAuth(m.spAuth).then(r);return true}
 if(m.sp){spAccess().then(t=>t?fetch('https://api.spotify.com/v1'+m.sp,{headers:{Authorization:'Bearer '+t}}).then(x=>x.ok?x.json():null):null).then(r,()=>r(null));return true}
 if(m.spUri){r(chrome.identity&&chrome.identity.getRedirectURL?chrome.identity.getRedirectURL():'n/a');return}
 if(m.spOut){chrome.storage.local.remove('spt');return}
 if(m.taste){fetch(chrome.runtime.getURL('taste.json')).then(x=>x.json()).then(r,()=>r(null));return true}
 if(m.u&&m.u.startsWith('https://ws.audioscrobbler.com/2.0/')){fetch(m.u).then(x=>x.json()).then(r,()=>r({}));return true}
 if(m.yt){fetch('https://www.youtube.com/results?sp=EgIQAQ%3D%3D&search_query='+encodeURIComponent(m.yt),{headers:{'Accept-Language':'en'}}).then(x=>x.text()).then(r,()=>r(''));return true}
 if(m.f&&OK.test(m.f)){fetch(m.f).then(x=>x.json()).then(j=>r({j}),()=>r(null));return true}
 if(m.i&&OK.test(m.i)){fetch(m.i).then(x=>x.arrayBuffer()).then(b=>{const u=new Uint8Array(b);let t='';for(let i=0;i<u.length;i+=8192)t+=String.fromCharCode.apply(null,u.subarray(i,i+8192));r('data:image/jpeg;base64,'+btoa(t))},()=>r(null));return true}
 if(m.np)post({method:'track.updateNowPlaying',artist:m.np.artist,track:m.np.title});
 if(m.scrobble)post({method:'track.scrobble','artist[0]':m.scrobble.artist,'track[0]':m.scrobble.title,'timestamp[0]':m.scrobble.ts});
 if(m.love)post({method:'track.love',artist:m.love.artist,track:m.love.title});
 if(m.like)chrome.tabs.create({url:'https://www.youtube.com/watch?v='+encodeURIComponent(m.like)+'&rrlike=1',active:false}).then(t=>{mark('lt',t.id);chrome.tabs.update(t.id,{muted:true})});
 if(m.close&&s.tab)chrome.tabs.remove(s.tab.id);
 if(m.auth)auth(m.auth,m.ak)});

/*X10*/
async function post(p){const {sec,sk,ak,srv}=await chrome.storage.local.get(['sec','sk','ak','srv']);if(!sk)return;
 if(srv)return fetch(srv.replace(/\/$/,'')+'/lfm/call',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({sk,params:p})}).then(r=>r.json()).catch(()=>{});
 if(!sec)return;p={...p,api_key:ak||KEY,sk};p.api_sig=sign(p,sec);p.format='json';return fetch('https://ws.audioscrobbler.com/2.0/',{method:'POST',body:new URLSearchParams(p)}).then(r=>r.json()).catch(()=>{})}
chrome.runtime.onMessage.addListener((m,s,r)=>{if(!m.lfmLogin)return;const srv=m.lfmLogin.replace(/\/$/,''),sl=ms=>new Promise(z=>setTimeout(z,ms));
 (async()=>{try{const j=await fetch(srv+'/lfm/token',{method:'POST'}).then(x=>x.json());chrome.tabs.create({url:j.url});r({url:1});
  for(let i=0;i<60;i++){await sl(3000);const q=await fetch(srv+'/lfm/session',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({token:j.token})}).then(x=>x.json()).catch(()=>({}));if(q.session){await chrome.storage.local.set({sk:q.session.key,lfmUser:q.session.name,srv});return}}}catch(e){r({err:String(e)})}})();return true});
chrome.runtime.onMessage.addListener((m,s,r)=>{if(m.depot){if(!m.depot.product){r({ok:false,error:'no product'});return}fetch('https://api.gumroad.com/v2/licenses/verify',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({product_id:m.depot.product,license_key:m.depot.key,increment_uses_count:'false'})}).then(x=>x.json()).then(j=>r({ok:!!(j.success&&!(j.purchase&&(j.purchase.refunded||j.purchase.chargebacked)))}),()=>r(null));return true}if(m.save){for(const svc of m.save.svc){const q=encodeURIComponent(m.save.a+' '+m.save.t),url=svc==='spotify'?'https://open.spotify.com/search/'+q+'/tracks':'https://music.apple.com/us/search?term='+q;chrome.tabs.create({url,active:false}).then(t=>{chrome.storage.session.get('svq').then(o=>chrome.storage.session.set({svq:{...(o.svq||{}),[t.id]:{svc,a:m.save.a,t:m.save.t}}}));chrome.tabs.update(t.id,{muted:true});setTimeout(()=>chrome.tabs.remove(t.id).catch(()=>{}),45000)})}return}if(m.saveme){chrome.storage.session.get('svq').then(o=>r((o.svq||{})[s.tab&&s.tab.id]||null));return true}});
chrome.runtime.onMessage.addListener((m,s,r)=>{if(!m.whoami)return;chrome.storage.session.get(['rt','lt']).then(o=>r({rr:(o.rt||[]).includes(s.tab?.id),like:(o.lt||[]).includes(s.tab?.id)}),()=>r({}));return true});

chrome.runtime.onMessage.addListener((m,s,r)=>{if(!m.radio)return;const R=m.radio;if(!/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(R.url)){r({error:'Use the local radio address'});return}fetch(R.url+'/api/admin/wanted',{method:'POST',headers:{'X-Key':R.key,'Content-Type':'application/json'},body:JSON.stringify({items:R.items})}).then(x=>x.json()).then(r,()=>r(null));return true});
