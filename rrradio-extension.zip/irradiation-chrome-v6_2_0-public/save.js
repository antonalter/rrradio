/* Runs on open.spotify.com and music.apple.com, only in tabs irradiation opened to save a loved track.
   It finds the track on the search page, saves it to the signed-in library, and closes the tab. */
chrome.runtime.sendMessage({saveme:1},job=>{if(!job)return;let n=0,opened=0;const done=()=>chrome.runtime.sendMessage({close:1});
 const iv=setInterval(()=>{if(++n>50){clearInterval(iv);done();return}
  if(job.svc==='spotify'){const row=document.querySelector('[data-testid="tracklist-row"]');if(!row)return;
   const b=row.querySelector('button[data-testid="add-button"],button[aria-label*="Liked Songs" i],button[aria-label*="playlist" i][aria-checked]');
   if(!b){row.dispatchEvent(new MouseEvent('mouseover',{bubbles:true}));return}
   if(b.getAttribute('aria-checked')!=='true')b.click();clearInterval(iv);setTimeout(done,1800)}
  else{const add=[...document.querySelectorAll('[role="menuitem"],button,li')].find(x=>/^\s*add to library\s*$/i.test(x.textContent||''));
   if(add){add.click();clearInterval(iv);setTimeout(done,1800);return}
   const more=document.querySelector('[data-testid="track-list-item"] [aria-label*="more" i],.songs-list-row [aria-label*="more" i],[data-testid="more-button"]');
   if(more&&!opened){opened=1;more.click()}}},600)});
