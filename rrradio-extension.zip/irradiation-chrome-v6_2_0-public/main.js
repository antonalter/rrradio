addEventListener('rr-load',e=>{const p=document.getElementById('movie_player');if(p&&p.loadVideoById)p.loadVideoById(e.detail)});
setInterval(()=>{const p=document.getElementById('movie_player'),d=p&&p.getVideoData&&p.getVideoData();if(d&&d.video_id)dispatchEvent(new CustomEvent('rr-vd',{detail:JSON.stringify({id:d.video_id,t:d.title,a:d.author})}))},1500);

(()=>{if(!/[?&]rr=1/.test(location.search)&&!sessionStorage.rr)return;
 const ev=d=>dispatchEvent(new CustomEvent('rr-key',{detail:d}));
 const mk=()=>{const ms=navigator.mediaSession;if(!ms)return;const h=(n,f)=>{try{ms.setActionHandler(n,f)}catch{}};
  h('play',()=>ev('play'));h('pause',()=>ev('pause'));h('nexttrack',()=>ev('next'));h('previoustrack',()=>ev('prev'))};
 mk();setInterval(mk,2000);
 addEventListener('rr-meta',e=>{try{const m=JSON.parse(e.detail);navigator.mediaSession.metadata=new MediaMetadata({title:m.t,artist:m.a,artwork:[{src:m.i,sizes:'480x360',type:'image/jpeg'}]})}catch{}})})();

addEventListener('rr-vol',e=>{const p=document.getElementById('movie_player');if(p&&p.setVolume){p.setVolume(+e.detail);if(p.isMuted&&p.isMuted())p.unMute()}});
