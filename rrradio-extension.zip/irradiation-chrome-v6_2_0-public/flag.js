const q=location.search;if(/[?&]rr=1/.test(q))sessionStorage.rr=1;if(/[?&]rrlike=1/.test(q))sessionStorage.rrlike=1;
